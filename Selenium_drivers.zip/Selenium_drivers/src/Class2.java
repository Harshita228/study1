import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Class2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\Rashmi\\Chennai VnV batch\\m4\\selenium jars\\new chrome driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("file:///D:/Rashmi/Chennai%20VnV%20batch/m4/PaymentDetails.html");
	   driver.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td/input")).click();
		//driver.findElement(By.xpath("/html/body/form/table/tbody/tr[7]/td/input")).sendKeys("ggjh");
		//wait
		WebDriverWait wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.alertIsPresent());
	
		/*switch to alert
		Alert alt=driver.switchTo().alert();
		String Expectedtxt="Hello i m an Alert box";
		String Actualtxt=alt.getText();
		Thread.sleep(5000);*/
		//driver.findElement(By.name("btnAlert")).click();
		
		Alert alt=driver.switchTo().alert();
		String alrttxt=alt.getText();
		System.out.println(alrttxt);
		alt.accept();
	}

}
