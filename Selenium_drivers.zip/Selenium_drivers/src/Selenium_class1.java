
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.firefox.FirefoxDriver;


public class Selenium_class1 {

	public static void main(String[] args) throws InterruptedException {
		//Step-1 launch empty browser
		//WebDriver driver=new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver", "D:\\Rashmi\\Chennai VnV batch\\m4\\selenium jars\\new chrome driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		/*driver.get("https://www.seleniumhq.org/download/");
	    //driver.findElement(By.linkText("sponser the Selenium project"));
		driver.findElement(By.partialLinkText("Selenium project")).click();
		List<WebElement> linkElements=driver.findElements(By.tagName("a"));
		System.out.println("No. of Links available on webpage "+linkElements.size());*/
        //Step-2 navigate to APP/URL
		driver.get("file:///D:/Rashmi/Chennai%20VnV%20batch/m4/ConferenceRegistartion.html");
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		//Thread.sleep(2000);
		
		//Step-3 to identify an element and perform an action
		driver.findElement(By.id("txtFirstName")).sendKeys("Jeson Hugins");
		driver.findElement(By.name("txtLN")).sendKeys("John");
		Thread.sleep(2000);
		WebElement size=driver.findElement(By.name("size"));
		
		Select sel=new Select(size);
		sel.selectByVisibleText("1");
		
		//sel.selectByIndex(0);
		//driver.findElement(By.xpath("input.[@type='href']")).click();
		driver.navigate().to("file:///D:/Rashmi/Chennai%20VnV%20batch/m4/PaymentDetails.html");
		driver.navigate().back();
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		//String act_txt=driver.findElement(By.xpath("//h3")).getText();
		//System.out.println(act_txt);
		String atr_val=driver.findElement(By.id("txtLastName")).getAttribute("name");
		System.out.println(atr_val);
		driver.manage().window().setPosition(new Point(50,50));
		driver.close();
		//driver.navigate().forward();
		//driver.navigate().refresh();
		//driver.findElement(By.xpath("/html/body/table/tbody/tr[80]/td[2]/span/span[6]")).click();
//driver.findElement(By.name("btnAlert")).click();
//Alertalt=driver.switch
	}

}
