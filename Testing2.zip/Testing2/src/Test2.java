import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.gargoylesoftware.htmlunit.javascript.host.Proxy;


public class Test2 {
	public static void main(String[] args) throws InterruptedException {
		//Proxy Setting


//Firefox versoin
		//IP**************************10.219.96.26
		System.setProperty("webdriver.firefox.bin","C:\\Users\\kartikks\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("newtwork.proxy.type",1);
		profile.setPreference("newtwork.proxy.http","chnproxy.igate.com");
		profile.setPreference("newtwork.proxy.http_port",8080);
		profile.setPreference("network.proxy.ssl", "chnproxy.igate.com");
		profile.setPreference("network.proxy.ssl_port", 8080);
		WebDriver driver=new FirefoxDriver();
		String baseUrl = "file:///D:/Chennai%20VnV%20batch/m1/Kartik-158166%20M1%20ASSIGNMENTS/HTML%20ASSIGNMENT/Main.html";
		driver.get(baseUrl);		
		driver.manage().window().maximize();
		//to store parent window id
		String parent_window = driver.getWindowHandle();
		System.out.println(parent_window);
		// click on Open Window button
		driver.findElement(By.linkText("New")).click();
		Thread.sleep(3000);
		//switching from parent window to child
		Set<String> s1= driver.getWindowHandles();

		Iterator<String> it = s1.iterator();

		while(it.hasNext())
		{
			String child_window=it.next();			
			if(!parent_window.equalsIgnoreCase(child_window))
			{
				System.out.println(child_window);
				//switching from parent to child window    
				driver.switchTo().window(child_window);
				Thread.sleep(2000);
				// Performing actions on child window  
				driver.findElement(By.partialLinkText("Copyright")).click(); 	
				driver.close();     		
			}  
		}		
		//Switching back to Parent Window  
		driver.switchTo().window(parent_window);  


	}
}
