import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class IEGrid {

	static DesiredCapabilities capabilities;
	static WebDriver driver;
	public static void setPropIE() {
		// FOR IE BROWSER	
		System.setProperty("webdriver.ie.driver","D:\\IEDriverServer.exe");
		capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		//driver = new InternetExplorerDriver(capabilities);
		capabilities.setPlatform(Platform.WINDOWS);
	}
	public static void setPropChrome(){

		System.setProperty("webdriver.chromedriver.driver", "D:/chromedriver.exe");
		capabilities = DesiredCapabilities.chrome();
		capabilities.setBrowserName("chrome");
		capabilities.setCapability("webdriver.chromedriver.driver", "D:/chromedriver.exe");
		//driver=new ChromeDriver();
		capabilities.setPlatform(Platform.WINDOWS);
	}
	public static void main(String[] args) throws InterruptedException, MalformedURLException 

	{
		//setPropIE();
		setPropChrome();
		//capabilities.setVersion(version);
		driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
		try {
			driver.get("file:///D:/misAppp.html");
			Thread.sleep(3000);
			System.out.println(driver.getTitle());
			By username= By.id("txtUserName");
			By password = By.xpath("//*[@id='txtPassword']");
			driver.findElement(username).sendKeys("Kartik");
			driver.findElement(password).sendKeys("djsgfdsg67");
			//		driver.quit();
		}
		catch(Exception ex){
			System.out.println("Hello"+ex);
		}
		//driver.quit();
	}
}
