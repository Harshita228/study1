

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerOptions;

public class Class5Window {
	static String driverPath = "D:\\IE\\";
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.InternetExplorer.driver",driverPath+"IEDriver.exe");
		InternetExplorerOptions options = new InternetExplorerOptions();
		//options.addArguments("--start-maximized");
		WebDriver driver = new ChromeDriver(options);
		driver.navigate().to("file:///D:/Training%20Matrial/V&V%20Automation%20Testing/Module%204/My%20Notes/openwin.html");
				
		//to store parent window id
			String parent_window = driver.getWindowHandle();
			System.out.println(parent_window);
		// click on Open Window button
		driver.findElement(By.name("Open")).click();
		Thread.sleep(2000);
		//switching from parent window to child
		Set<String> s1= driver.getWindowHandles();
		
		Iterator<String> it = s1.iterator();
		
		while(it.hasNext())
		{
			String child_window=it.next();			
			if(!parent_window.equalsIgnoreCase(child_window))
			{
			System.out.println(child_window);
			//switching from parent to child window    
     		driver.switchTo().window(child_window);
     		Thread.sleep(5000);
      // Performing actions on child window  
     		driver.findElement(By.linkText("LEARN HTML")).click(); 	
     		driver.close();     		
     	}  
		}		
	      //Switching back to Parent Window  
	     	driver.switchTo().window(parent_window);  
		
	     	
	    
	}

}
