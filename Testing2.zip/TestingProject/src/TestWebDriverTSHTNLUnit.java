import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;


public class TestWebDriverTSHTNLUnit {

	public static void main(String[] args)
	{

		System.setProperty("webdriver.phantomjs.driver", "D:\\Chennai VnV batch\\m4\\Demos\\phantomjs.exe");
		// Create a new instance of the HTMLUnit driver
        WebDriver driver = new PhantomJSDriver();

        // And now use this to visit Google
        driver.get("http://www.google.com/");         
        System.out.println("Page title is: " + driver.getTitle()); 
	}

}
