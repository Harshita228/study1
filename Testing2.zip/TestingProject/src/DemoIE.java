import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class DemoIE {
	public static void main(String[] args) throws InterruptedException {
		// FOR IE BROWSER	
		System.setProperty("webdriver.ie.driver","D:\\IEDriverServer.exe");
		DesiredCapabilities cap = DesiredCapabilities.internetExplorer();
		cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		WebDriver driver = new InternetExplorerDriver(cap);
// FOR CHROME BROWSER		
//		System.setProperty("webdriver.chrome.driver","C:\\Users\\kartikks\\Desktop\\chromedriver_win32\\chromedriver.exe");
//		WebDriver driver = new ChromeDriver();

		String baseUrl = "file:///D:/Chennai%20VnV%20batch/m1/Kartik-158166%20M1%20ASSIGNMENTS/HTML%20ASSIGNMENT/Main.html";
		driver.get(baseUrl);	
		System.out.println("Title: "+driver.getTitle());
		driver.manage().window().maximize();
		//to store parent window id
		String parent_window = driver.getWindowHandle();
		System.out.println(parent_window);

			// click on Open Window button
		//	driver.findElement(By.linkText("New")).click();
		new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(By.linkText("New"))).click();
			Thread.sleep(3000);
			//switching from parent window to child
			Set<String> s1= driver.getWindowHandles();
			
			Iterator<String> it = s1.iterator();
			
			while(it.hasNext())
			{
				String child_window=it.next();			
				if(!parent_window.equalsIgnoreCase(child_window))
				{
				System.out.println(child_window);
				//switching from parent to child window    
		 		driver.switchTo().window(child_window);
		 		Thread.sleep(2000);
		  // Performing actions on child window  
		 		driver.findElement(By.partialLinkText("Copyright")).click(); 	
		 		driver.close();     		
		 	}  
			}		
		      //Switching back to Parent Window  
		     	driver.switchTo().window(parent_window);  
			
				
	}
}
